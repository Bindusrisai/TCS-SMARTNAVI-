package com.navigation.navin;

public class Consultations {
    public String day;
    public String hours;
}
