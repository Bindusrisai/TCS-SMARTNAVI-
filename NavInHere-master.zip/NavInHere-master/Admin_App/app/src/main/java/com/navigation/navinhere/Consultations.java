package com.navigation.navinhere;

public class Consultations {
    public String day;
    public String hours;
}

